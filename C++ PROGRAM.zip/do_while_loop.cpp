#include<iostream>
using namespace std;
int main()
{
    int i=0;
    do
    {
        cout<<i;
        cout<<" this will execute in any case ";
        i++;
    } while (true);
return 0;

}