#include<iostream>
using namespace std;
// int sum(int a,int b)
// {
//  int c=a+b;
//  return c;

// }
//this swapping will not work 
void swap(int a,int b){
int temp=a;
a=b;
b=temp;
}
// CALL BY REFERENCE USING POINTER 
void swap_pointer(int *a,int *b){
int temp=*a;
*a=*b;
*b=temp;
}



void swap_reference_var (int &a,int &b){
int temp=a;
a=b;
b=temp;
}


int main()
{
    int x=9,y=8;
// cout<<" the sum of 5 and 8 is :"<<sum(5,8);
cout<<"  using function swap \n ";
cout<<"before swapping x:"<<x<<"   y :"<<y;

swap(x,y);
cout<<"\n after swapping x :"<<x<<"  y :"<<y;


cout <<"\n using swap pointer function\n  ";

cout<<"after swapping x:"<<x<<"  y :"<<y;
swap_pointer(&x,&y);
cout<<"\n after swapping x:"<<x<<"  y :"<<y;


cout <<"\n using reference variable swap function\n  ";

cout<<"after swapping x:"<<x<<"  y :"<<y;
swap_reference_var(x,y);
cout<<"\n after swapping x:"<<x<<"  y :"<<y;
 return 0;
 }
