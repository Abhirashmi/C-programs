#include<iostream>
using namespace std;
int main()
{
for (int  i = 1; i <= 100; i++)
{
    cout<<i<<endl;
    
}

// EXAMPLE OF INFINITE LOOP//
for (int j = 0; 10<77; j++)
{
    cout<<j<<endl;
}



    return 0;
}