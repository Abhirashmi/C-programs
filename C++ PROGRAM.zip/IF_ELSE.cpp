#include<iostream>
using namespace std;
int main()
{
    int age;
cout<<"this is tutorial 9"<<endl;
cout<<"tell me your age "<<endl;
cin>>age;
if (age<18)
{
   cout<<"you cannot come to my party "<<endl;
}
else if ( age==18)
{
    cout<<"you are a kind and will be allowed through a kid passs which you have to buy from my website "<<endl;
}
else
{
    cout<<"you are welcome ";
}


    return 0;
}