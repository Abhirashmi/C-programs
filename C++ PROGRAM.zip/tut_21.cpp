#include<iostream>
using namespace std;


class employee
{
private:
    int a,b ,c;
public:
int d,e;
void setdata(int a,int b,int c);//DECLARATION
void getdata(){
cout<<"the value of a is "<<a<<endl;
cout<<"the value of b is "<<b<<endl;
cout<<"the value of c is "<<c<<endl;
cout<<"the value of d is "<<d<<endl;
cout<<"the value of e is "<<e<<endl;
}
};




void  employee::setdata(int a1,int b1,int c1){
a=a1;
b=b1;
c=c1;
}

int main()
{

employee abhi;
// abhi.a=999;PRIVATE//this will throw error as this is private :(
abhi.d=7;
abhi.e=55;
abhi.setdata(1,2,4);
abhi.getdata();


 return 0;
 }
