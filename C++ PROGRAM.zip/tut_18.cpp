#include<iostream>
using namespace std;
int factorial(int n){
    if (n<=1)
    {
        return 1;
    }

    return n* factorial(n-1);
}


int fib(int a ){
    if(a<2)
    {
        return 1;
    }
return fib(a-1)+fib(a-2);
    
}

int main()
{
    int a;
    cout<<"enter the number whose factorial  and fibbonacci series you want to find  :\n ";
    cin>>a;
    cout<<" factorial of "<<a <<"  is : "<<factorial(a);
    cout<<" fibonnacci series till  "<<a <<"  is : "<<fib(a);








 return 0;
 }
