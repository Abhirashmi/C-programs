#include<iostream>
using namespace std;

int main()
{
// int a= 77;
// int* p= &a;
// cout<<"the value of a is :"<<*p<<endl;
// new keyword  
// int *p =new int(40);
float *p=new  float(88);
int *arr= new int[3];
cout<<"BEFORE DELECTION "<<endl;
arr[0]=1;
arr[1]=77;
arr[2]=9;
cout<<"the value at index 0 of aaray :"<<arr[0]<<endl;
cout<<"the value at index 1 of aaray :"<<arr[1]<<endl;
cout<<"the value at index 2 of aaray :"<<arr[2]<<endl;
delete arr;
cout<<" AFTER DELETION "<<endl;
cout<<"the value at index 0 of aaray :"<<arr[0]<<endl;
cout<<"the value at index 1 of aaray :"<<arr[1]<<endl;
cout<<"the value at index 2 of aaray :"<<arr[2]<<endl;
 return 0;
 }
