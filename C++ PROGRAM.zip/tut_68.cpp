#include<iostream>
using namespace std;
template<class T>
class abhi{
    public:
    T data;
    abhi(T a){
        data=a;

    }
void display();
    // void display(){
    //     cout<<" \n the value of data is :"<<data<<endl;
    // }

};

template <class T>
void abhi<T>::display(){
 cout<<" \n the value of data is :"<<data<<endl;

}

void func(int  a){
    cout<<"i am func 1 function "<<a<<endl;

}

 

template< class T> 
void func1(T a){
    cout<<"i am tempalatise function "<<a<<endl;

}

int main()
{
func(33);//EXACT MATCH TAKES THE HIGHEST PRIORITY 
func1(44); //EXACT MATCH runs !!!!!!!!!!!!


// {
//     abhi<int> a(33);
//     cout<<a.data;

// a.display();
 return 0;
 }
