#include<iostream>
using namespace std;

class student {
    protected:
int roll_number;
public:
void set_roll_number(int );
void get_roll_number(void);

};

void student :: set_roll_number(int r ){
roll_number=r;
}


void student :: get_roll_number (void ){
cout<<"the roll number is :"<<roll_number<<endl;
}

class exam : public student{
protected:
float physics;
float maths;
float chemistry;

public:
void set_marks(float,float,float);
void get_marks(void);

};


void exam::set_marks(float p, float m , float c ){
physics=p;
chemistry=c;
maths=m;

}


void exam::get_marks(void){
cout<<"marks obtained in physics are : "<<physics<<endl;
cout<<"marks obtained in chemistry are : "<<chemistry<<endl;
cout<<"marks obtained in maths  are : "<< maths<<endl;
}


class result : public exam{
float percentage;
public:
void display(){
get_roll_number();
get_marks();
cout<<" your percentage is :   \n "<<(maths+chemistry+physics)/3<<endl;
}



};

int main()
{
result r1,r2;
r1.set_roll_number(1828223);
r1.set_marks(44,68,96);
r1.display();


r2.set_roll_number(1828224);
r2.set_marks(99.88,68.7,99.8);
r2.display();




 return 0;
 }






// #include <iostream>
// using namespace std;

// class Student
// {
// protected:
//     int roll_number;

// public:
//     void set_roll_number(int);
//     void get_roll_number(void);
// };

// void Student ::set_roll_number(int r)
// {
//     roll_number = r;
// }

// void Student ::get_roll_number()
// {
//     cout << "The roll number is " << roll_number << endl;
// }

// class Exam : public Student
// {
// protected:
//     float maths;
//     float physics;

// public:
//     void set_marks(float, float);
//     void get_marks(void);
// };

// void Exam ::set_marks(float m1, float m2)
// {
//     maths = m1;
//     physics = m2;
// }

// void Exam ::get_marks()
// {
//     cout << "The marks obtained in maths are: " << maths << endl;
//     cout << "The marks obtained in physics are: " << physics << endl;
// }

// class Result : public Exam
// {
//     float percentage;

// public:
//     void display_results()
//     {
//         get_roll_number();
//         get_marks();
//         cout << "Your result is " << (maths + physics) / 2 << "%" << endl;
//     }
// };

// int main()
// {
//     /*
//     Notes: 
//         If we are inheriting B from A and C from B:[ A--->B--->C ]
//         1. A is the base class for B and B is the base class for C
//         2. A-->B-->C is called Inheritance Path
//     */

//     Result harry;
//     harry.set_roll_number(420);
//     harry.set_marks(94.0, 90.0);
//     harry.display_results();
//     return 0;
// }