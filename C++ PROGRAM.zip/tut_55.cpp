#include<iostream>
using namespace std;
class BaseClass{
    public:
        int var_base;
        void display(){
            cout<<"Dispalying Base class variable var_base "<<var_base<<endl;
        }
};

class DerivedClass : public BaseClass{
    public:
            int var_derived;
            void display(){
                cout<<"Dispalying Base class variable var_base "<<var_base<<endl;
                cout<<"Dispalying Derived class variable var_derived "<<var_derived<<endl;
            }
};

int main(){
    BaseClass * base_class_pointer;
    BaseClass obj_base;
    DerivedClass obj_derived;
    base_class_pointer = &obj_derived; // Pointing base class pointer to derived class

    base_class_pointer->var_base = 34;
    // base_class_pointer->var_derived= 134; // Will throw an error
    base_class_pointer->display();

    base_class_pointer->var_base = 3400; 
    base_class_pointer->display();

    DerivedClass * derived_class_pointer;
    derived_class_pointer = &obj_derived;
    derived_class_pointer->var_base = 9448;
    derived_class_pointer->var_derived = 98;
    derived_class_pointer->display();

    return 0;
}



// #include<iostream>
// using namespace std;

// class base{
// public:
// int var_base;
// public:
// void display(void){
// cout<<"the value of variable var_base is :"<<var_base<<endl;

// }
// };


// class derived :public base{
// public:
// int var_derived;
// void display(void){
// cout<<"the value of variable var_derived is :"<<var_derived<<endl;
// cout<<"the value of variable var_base is :"<<var_base<<endl;

// }
// };


// int main()
// {
// base *base_pointer;
// base obj_base;
// derived d_object;
// base_pointer=&d_object;//pointing base class pointer to  derived classs 
// base_pointer->var_base=77;
// base_pointer->display();
// // base_pointer->var_derived();//will throw error as it is not the member function   

// derived *derived_pointer;
// derived_pointer=&d_object;
// derived_pointer->var_derived=99;
// derived_pointer->display();
//  return 0;
//  }
