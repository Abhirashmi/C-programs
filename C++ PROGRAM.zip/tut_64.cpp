#include<iostream>
using namespace std;
template <class T>
class vector {
    public:
T* arr;
int size;
public:
vector(int m){
size=m;
arr =new T [size];

}

T dotproduct(vector &v){
T d=0;
for(int i = 0; i < size; i++)
{
    d= d+(this->arr[i] * v.arr[i]);  

}

return d;
}

};
int main()
{
// vector v1(4);
// v1.arr[0]=22;
// v1.arr[1]=99;
// v1.arr[2]=88;
// v1.arr[3]=87;

// vector v2(4);
// v2.arr[0]=62;
// v2.arr[1]=989;
// v2.arr[2]=84;
// v2.arr[3]=472;

//  int a= v1.dotproduct(v2);



 vector <float> v1(4);
v1.arr[0]=28.92;
v1.arr[1]=99.09;
v1.arr[2]=88.08;
v1.arr[3]=8.97;

vector<float> v2(4);
v2.arr[0]=69.2;
v2.arr[1]=99.89;
v2.arr[2]=84.7;
v2.arr[3]=47.82;


float a= v1.dotproduct(v2);

 cout<<"the value of dot product of v1 and v2 :"<<a<<endl;



//  vector <double> v1(4);
// v1.arr[0]=28.92;
// v1.arr[1]=99.09;
// v1.arr[2]=88.08;
// v1.arr[3]=8.97;

// vector<double> v2(4);
// v2.arr[0]=69.2;
// v2.arr[1]=99.89;
// v2.arr[2]=84.7;
// v2.arr[3]=47.82;


// double a= v1.dotproduct(v2);

//  cout<<"the value of dot product of v1 and v2 :"<<a<<endl;
 return 0;
 }
