// C++ implementation of the approach 
#include <bits/stdc++.h> 
using namespace std; 

// Function to return the sum of the elements 
// of all possible pairs from the array 
int sumPairs(int arr[], int n) 
{ 

	// To store the required sum 
	int sum = 0; 

	// Nested loop for all possible pairs 
	for (int i = 0; i < n; i++) { 
		for (int j = 0; j < n; j++) { 

			// Add the sum of the elements 
			// of the current pair 
			sum += (arr[i] + arr[j]); 
		} 
	} 
	return sum; 
} 

// Driver code 
int main() 
{ 
	int arr[] = { 1, 2, 3 }; 
	int n = sizeof(arr) / sizeof(arr[0]); 

	cout << sumPairs(arr, n); 

	return 0; 
} 
