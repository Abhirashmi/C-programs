#include<iostream>
#include<functional>
#include<algorithm>
using namespace std;

int main()
{

    int arr[] ={6,99,89,67,54,33,231,7};
    sort(arr,arr+7);
    sort(arr,arr+7,greater<int>());
    for (int i = 0; i < 8; i++)
    {
       cout<<arr[i]<<endl;
    }
    

 return 0;
 }
