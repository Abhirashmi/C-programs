#include<iostream>
using namespace std;
// typedef struct employee
//     {
//         char fav_char;
//         int eid;
//         int salary;
//     } ep;
    
int main()
{
// ep abhi;
//     //struct employee abhi;
//     abhi.eid=122;
//     abhi.fav_char='g';
//     abhi.salary=99999;
//     cout<<"abhi's salary "<<abhi.salary<<endl;
//     cout<<"abhi's favroite character "<<abhi.fav_char<<endl;
//     cout<<"abhi's employee id  "<<abhi.eid<<endl;
    

    union money
    {
        
    };

enum meal{breakfast,lunch,refreshment,dinner };
cout<<breakfast;
cout<<lunch;
cout<<refreshment;
cout<<dinner;
meal m1= breakfast;
cout<<m1;

    //  employee
    // {
    //     char fav_char;
    //     int eid;
    //     int salary;
    // } ep;
 return 0;
 }
