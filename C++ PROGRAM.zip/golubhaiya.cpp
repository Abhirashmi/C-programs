#include<iostream>
using namespace std;
int main()
{
  printf("Program to calculate the sum of all even number from (100,1050)"
  " using while  loop \n ");
  int sum=0;
  int i=100;
  while (i <= 1050)
  {
      if (i % 2==0)
      {
      sum=sum+i;
      }
      i=i+1;   
  }
  printf("the sum of all the even numbers from (100 ,1050) is : %d ",sum);
  return 0;
}