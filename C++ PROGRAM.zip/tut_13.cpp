#include<iostream>
using namespace std;

int main()
{
//ARRAYS
int marks[4]={34,65,99,54};
for (int  i = 0; i < 4; i++)
{
    marks[3]=444;
    cout<<marks[i]<<endl;
}

cout<<"bye ";
//POINTERS AND ARRAYS
int *p=marks;
cout<<p<<endl;
cout<<(p+1)<<endl;
cout<<(p+2);

cout<<endl<<*p<<endl;
cout<<*(p+1)<<endl;
cout<<*(p+2);

 return 0;
 }
