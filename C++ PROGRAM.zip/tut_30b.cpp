#include<iostream>
using namespace std;
class point {
int x,y;
public:
point(int a, int b)
{
 x=a;
 y=b;
}
 
 void display(void){
cout<<"the point is : ( "<<x<<", "<<y<<" )"<<endl;
 }
};

int main()
{
    
    point p(1,1);
    point w(7,1);
    point t(1,0);
    p.display();
w.display();
t.display();

 return 0;
 }
