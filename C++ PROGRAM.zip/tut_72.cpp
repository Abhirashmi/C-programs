#include<iostream>
#include<list>
using namespace std;

int main()
{
    
    list<int >list1;//list of  0 length
    //list<int >list2(7);//empty list of size 7
    list1.push_back(5);
    list1.push_back(46);
    list1.push_back(77);
    list1.push_back(98);
    list1.push_back(43);

    list <int>::iterator iter;
    iter=list1.begin();
    cout<<*iter<<endl;
    cout<<*iter+1<<endl;
 return 0;
 }
