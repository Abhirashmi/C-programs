#include<iostream>
using namespace std;

int main()
{
for (int i=0; i<30 ; i++)
{
 cout<<i<<endl;
 if(i==4){
     break;
 }

}

cout<<"abhi ";
for (int i=0; i<30 ; i++)
{
if(i==4)
 {
    

     continue;
 }
 cout<<i<<endl;
}
    
return 0;

 }
 
 
