#include<iostream>

using namespace std;

int main() {
	char C;
	int L,W,N;
	std::cin>>C>>L>>W>>N;

	for(int row=0;row<2*N;row++){

		for(int smallrow=0;smallrow<L;smallrow++){

			for(int col=0;col <2*N;col++){
				for (int smallcol = 0; smallcol <W; smallcol++)
				{
					if(row%2==col%2){
						std::cout <<C;

					}
					else {
						std::cout<<" ";
					}
				}
				
			}
			std::cout<<std::endl;
		}

	}
	return 0;
}