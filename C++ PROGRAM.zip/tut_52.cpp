#include<iostream>
using namespace std;

class ShopItem
{
    int id;
    float price;
    public:
        void setData(int a, float b){
            id = a;
            price = b;
        }
        void getData(void){
            cout<<"Code of this item is "<< id<<endl;
            cout<<"Price of this item is "<<price<<endl;
        }
};
        // 1 2 3
        //   ^
        //   |
        //   |
        //   ptr
        // ptrTemp
int main(){
    int size = 3;
    // int *ptr = &size;
    // int *ptr = new int [34];

    // 1. general store item
    // 2. veggies item
    // 3. hardware item
    ShopItem *ptr = new ShopItem [size];
    ShopItem *ptrTemp = ptr;
    int p, i;
    float q;
    for (i = 0; i < size; i++)
    {
        cout<<"Enter Id and price of item "<< i+1<<endl;
        cin>>p>>q;
        // (*ptr).setData(p, q);
        ptr->setData(p, q);
        ptr++; 
    }

    for (i = 0; i < size; i++)
    {
        cout<<"Item number: "<<i+1<<endl;
        ptrTemp->getData();
        ptrTemp++;
    }
    
    
    return 0;
}















// #include<iostream>
// using namespace std;

// class shop{
// int id ;
// float price;
// public:
// void setData(int a, float b){
// id=a;
// price=b;

// }

// void getData(void){
// cout<<"the value of id for this item is :"<<id<<endl;
// cout<<"the value of price for this item is :"<<price<<endl;

// }





// };
// int main()
// {
// // shop s;
// // s.setData(3,99.07);
// // s.getData();


// // int *ptr= &size;
// // int *ptr= new int [40];
// int size=2;
// shop *ptr= new shop [size];
// for (int  i = 0; i < size; i++)
// {
     
// }


//  return 0;
//  }
