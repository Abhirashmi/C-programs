#include<iostream>
#include<fstream>

using namespace std;

int main()
{

    ofstream aout("sample.txt");
    cout<<"enter your name ";
    string name;
    cin>>name;

    aout<<name <<endl ;
    aout<<"my name is " +name;
    aout.close();

    ifstream ain("sample.txt");
    string content;
    ain>>content;
    cout<<"the content of the file is :"<<content<<endl; 
    ain.close();
    
 return 0;
 }
