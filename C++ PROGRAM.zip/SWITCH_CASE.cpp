#include<iostream>
using namespace std;
int main()
{
    int marks;
cout<<"checking switch case "<<endl;
cout<<"enter your total marks" <<endl;
cin>>marks;
int val;
if((marks<=100)&&(marks>90))
{
val=1;
}
else if((marks<=90)&&(marks>80))
{
val=2;
}
else if((marks<=80)&&(marks>70))
{
val=3;
}
else if((marks<=70)&&(marks>60))
{
val=4;
}
else if ((marks<=60)&&(marks>50))
{
val=5;
}

switch (val)
{
case 1:
cout<<" you have got marks ranging from 90+ to 100 "<<" \n CONGRATS !!!"<<endl;
 
    break;
    case 2:
cout<<" you have got marks ranging from 80+ to 90 "<<" \n very good !!!"<<endl;
 
    break;
    case 3:
cout<<" you have got marks ranging from 70+ to 80 "<<" \n good !!!"<<endl;
 
    break;
    case 4:
cout<<" you have got marks ranging from 60+ to 70 "<<" \n not good  !!!"<<endl;
 
    break;
    case 5:
cout<<" you have got marks ranging from 50+ to 60 "<<" \n study hard  !!!"<<endl;
 
    break;

default:
cout<<"you have got less than 50 ";
    break;
}






cout<<"bye!!!";

    return 0;
}