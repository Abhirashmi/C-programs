#include<iostream>
using namespace std;
int main()
{
// int i=0;
// while(i<66)
// {
//     cout<<i<<endl;
//     i++;
// }

// i=0;
// while(i>7)
// {
//     cout<<i<<endl;
//     i++;
// }

//*************INFINITE WHILE LOOP **********************
int i=0;
while(true)
{
    cout<<i<<endl;
    i++;
}
return 0;
}
