#include<iostream>
using namespace std;
//this is abhirashmi checking the single line comments
// jjj
// nnbb
// knknk
// vghdrsyh
// cghcjcj
// vjvjhvjhvhvjhv
int main()
{
    int sum=8;
cout<<"hello world     "<< sum;
return 0;
}