// CPP program to find sum of 
// prime divisors of N 
#include <bits/stdc++.h> 
using namespace std; 
#define N 1000005 

// Function to check if the 
// number is prime or not. 
bool isPrime(int n) 
{ 
	// Corner cases 
	if (n <= 1) 
		return false; 
	if (n <= 3) 
		return true; 

	// This is checked so that we can skip 
	// middle five numbers in below loop 
	if (n % 2 == 0 || n % 3 == 0) 
		return false; 

	for (int i = 5; i * i <= n; i = i + 6) 
		if (n % i == 0 || n % (i + 2) == 0) 
			return false; 

	return true; 
} 

// function to find sum of prime 
// divisors of N 
int SumOfPrimeDivisors(int n) 
{ 
	int sum = 0; 
	for (int i = 1; i <= n; i++) { 
		if (n % i == 0) { 
			if (isPrime(i)) 
				sum += i; 
		} 
	} 
	return sum; 
} 
// Driver code 
int main() 
{ 
	int n = 100; 
	cout << "Sum of prime divisors of 60 is " << SumOfPrimeDivisors(n) << endl; 
} 
