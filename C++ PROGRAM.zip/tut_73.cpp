#include<iostream>
#include<map>
#include<string>
using namespace std;

int main()
{
map<string , int> marksmap; 
marksmap["abhi"] = 22;
marksmap["abhirashmi"]=62;
marksmap["rashmi"]=2;

map<string , int>:: iterator itr;
for (itr = marksmap.begin(); itr!=marksmap.end() ;itr++)
{
    cout<<(*itr).first<<" "<<(*itr).second<<endl  ;
}


 return 0;
 }
 