#include<iostream>
using namespace std;

class Complex{
    int real, imaginary;
    public:
        void getData(){
            cout<<"The real part is "<< real<<endl;
            cout<<"The imaginary part is "<< imaginary<<endl;
        }

        void setData(int a, int b){
            real = a;
            imaginary = b;
        }

};
int main(){
    // Complex c1;
    // Complex *ptr = &c1;
    Complex *ptr = new Complex;
    // (*ptr).setData(1, 54); is exactly same as
    ptr->setData(1, 54);

    // (*ptr).getData(); is as good as 
    ptr->getData(); 


    // Array of Objects
    Complex *ptr1 = new Complex[4]; 
    ptr1->setData(1, 4); 
    ptr1->getData();
    return 0;
}


// #include<iostream>
// using namespace std;

// class complex{
// int real, imaginary;
// public:
// void getdata(){
// cout<<" the value of real  part is :"<<real<<endl;
// cout<<" the value of imaginary  part is :"<<imaginary<<endl;
// cout<<" and hence  the complex number is : "<<real<<" + "<<imaginary<<"i "<<endl;

// }
// void setdata(int a ,int b){
//     real=a;
// imaginary=b;

// }




// };



// int main()
// {
//     complex c;
//     //c.setdata(4,7);
//     //c.getdata();
//     complex *ptr=&c;
//     (*ptr).setdata(55,9);
//     (*ptr).getdata();

//  return 0;
//  }
