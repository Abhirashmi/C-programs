#include<stdio.h>
#include<conio.h>
int main (int argc, char *argv[])
{
  clrscr();
  int ar[100];
  int r,a=0,b=1,i,j,c;
  for(i=0;i<100;i++)
  {
    ar[i]=0;
  }
  printf("\n Enter the range:(less than 100) ");
  scanf("%d",&r);
  ar[1]=1;
  for(i=2;i<r;i++)
  {
       ar[i]=a+b;
       a=b;
       b=ar[i];
  }
  for(i=0;i<r;i++)
  {
    for(j=0;j<r;j++)
    {
      if(ar[j]!=i)
      {
          c=1;
      }
    }
    if(c==1)
       printf("%d ",i);
  }
  printf("\n are the non fibonacci numbers between 0 and %d",r);
  getch();
}