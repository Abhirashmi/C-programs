#include<iostream>
#include<vector>
using namespace std;
template <class T>
void display(vector<T> &v){
cout<<"displaying this vector  !!!!!\n "; 
}

// for(int i = 0; i < v.size(); i++)
// {
//     cout<<v[i]<<"   ";
// }
// cout<<endl;


int main()
{
   //ways to create a vector 
 vector<int> vec1; //ZERO LENGTH INTEGER VECTOR !!!
  vector<int>vec2(4);
   vector<char>vec3(4);
   vector<char>vec4(vec3);// 4 ELEMENT CHARACTER VECTOR  3 FROM VEC 4 .
    vector<double>vec5(4);
     vector<int>v(5,6);
     display(v);
     cout<<vec4.size();
  
// int element,size;
// cout<<"hello user enter the size of the vector "<<endl;
// cin>>size;
// for (int  i = 0; i < size; i++)
// {
// cout<<"enter the  element number "<<i+1<<" to add to this vector"<<endl;
// cin>>element;
// vec1.push_back(element);
// cout<<"pushed element : ";
// display (vec1);
//}
// cout<<"popping element ";
// vec1.pop_back();
// display (vec1);
// vector <int>:: iterator iter =vec1.begin();
// vec1.insert(iter,3,45);
// display(vec1);



 return 0;
 }
