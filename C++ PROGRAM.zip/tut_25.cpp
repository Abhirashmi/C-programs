#include<iostream>
using namespace std;

class employee
{
    int id;
    int salary=122;
public:

void setid(void){//public members
    cout<<"enter the id of the employee"<<endl;
    cin>>id;
}

void getid(void){
    cout<<" the id of the employee is "<<id<<endl;
    cout<<"salary =122"<<endl;
    
}


};

int main()
{
    employee abhi_company[10];
    for (int i = 0; i < 10; i++)
    {
        abhi_company[i].setid();
        abhi_company[i].getid();
    }
    

    // abhi.setid();
    // abhi.getid();
    // arnav.setid();
    // arnav.getid();
 return 0;
 }
