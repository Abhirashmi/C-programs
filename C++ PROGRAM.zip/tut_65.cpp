#include<iostream>
using namespace std;
template< class T1 , class T2>
class my_class{
public:
T1 data1;
T2 data2;
my_class(T1 a , T2 b ){
    data1 =a;
    data2=b;
}
void display(){

cout<<"the value of data1 and data 2 are :"<<data1<<"  and  "<<data2<<endl;    
cout<<this->data1<<endl<<this->data2;


}

};

int main()
{
// my_class <int  , char> obj(1,'c');
// obj.display();

my_class <int  , float> obj(1,77.9mi);
obj.display();











 return 0;
 }

