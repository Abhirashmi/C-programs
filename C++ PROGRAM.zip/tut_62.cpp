#include<iostream>
#include<fstream>
using namespace std;

int main()
{
    ofstream out;
    out.open("sample.txt");
    out<<"this is me\n  ";
    out<<"this is me \n";
    out<<"this is me \n ";
    out<<"this is me \n ";
    out.close();



    ifstream in;
    string st;
    // string st,st1,st2;
    in.open("sample.txt");
    // in>>st>>st1>>st2;
    // cout<<st<<st1<<st2;

    while (in.eof()==0){
    getline(in,st);
    cout<<st<<endl;


    }
    {
        /* code */
    }
    
    in.close();


 return 0;
 }
