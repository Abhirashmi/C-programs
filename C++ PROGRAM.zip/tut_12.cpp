#include<iostream>
using namespace std;

int main()
{
//(address of )operstor 
int a =99;
int *b=&a;
cout<<" address of a :"<<b<<endl<<&a;

// value at address -dereference operator 
cout<<"  value at adddress "<<*b;

//pointer to pinter
int **c=&b;
cout<<endl<<**c;

 return 0;
 }
