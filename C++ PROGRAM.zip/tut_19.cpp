#include<iostream>
using namespace std;

int add(int a, int b){
    cout<<"using function with 2 arguments";
    return a+b;
}

 
int add(int a, int b,int c){
    cout<<"using function with 3 arguments";
    return a+b+c;
}

//volume of cylinder
int volume(int r, int h){
return (3.14 *r*r*h);

}

//volume of cuboid
int volume(int a){
return (a*a*a);

}//volume of rectangle 
int volume(int l, int b, int h){
return (l*b*h);

}
int main()
{

    cout<<" add  is :"<<add(3,4)<<endl;
    cout<<" add  is :"<<add(3,4,7)<<endl;
    cout<<" volume of cuboid  is :"<<volume(7)<<endl;
    cout<<" volume of cylinder is  :"<<volume(3,7)<<endl;
    cout<<" volume of rectangle is  :"<<volume(9,9,9)<<endl;
    
 return 0;
 }
