// C++ program to find the largest sum zigzag sequence 
#include <bits/stdc++.h> 
using namespace std; 

const int MAX = 100; 

// Returns largest sum of a Zigzag sequence starting 
// from (i, j) and ending at a bottom cell. 
int largestZigZagSumRec(int mat[][MAX], int i, 
								int j, int n) 
{ 
// If we have reached bottom 
if (i == n-1) 
	return mat[i][j]; 

// Find the largest sum by considering all 
// possible next elements in sequence. 
int zzs = 0; 
for (int k=0; k<n; k++) 
	if (k != j) 
	zzs = max(zzs, largestZigZagSumRec(mat, i+1, k, n)); 

return zzs + mat[i][j]; 
} 

// Returns largest possible sum of a Zizag sequence 
// starting from top and ending at bottom. 
int largestZigZag(int mat[][MAX], int n) 
{ 
// Consider all cells of top row as starting point 
int res = 0; 
for (int j=0; j<n; j++) 
	res = max(res, largestZigZagSumRec(mat, 0, j, n)); 

return res; 
} 

// Driver program to test above 
int main() 
{ 
	int n = 3; 
	int mat[][MAX] = { {4, 2, 1}, 
						{3, 9, 6}, 
						{11, 3, 15}}; 
	cout << "Largest zigzag sum: " << largestZigZag(mat, n); 
	return 0; 
} 
