#include <iostream>
using namespace std;
int count = 0;
class num
{
    public : num()
    {

        count++;
        cout << "this is the time when constructor is called for object number  " << count << endl;
    }

    ~num()//tilt 
    {
        cout << "this is the time whem my destructor is called for count" << count << endl ;
        count--;
    }
};

int main()
{
    cout<<"we are inside our main function \n  "<<endl;
cout<<" creating first object named n1  \n    "<<endl;
num n1;
{
    cout<<"entering this block    \n"<<endl;
    cout<<"creating two more object inside n1 named n2 and n3   \n  "<<endl;
    num n2,n3;
    cout<<"we are exiting this block \n "<<endl;
}
cout<<"we are back in our main function   \n "<<endl;
    return 0;
}
