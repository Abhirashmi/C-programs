#include<iostream>
using namespace std;
int c=908;
int main()
{
    // *********************BUILD IN DATA TYPES ******************************
//     int a,b,c;
//     cout<<"enter the value of a \n";
// cin>>a;
// cout<<"enter the value of b \n";
// cin>>b;


// c=a+b;
// cout<<"the sum of a and b is \n :"<<c;
// cout<<"the value of global c  is "<<::c;


// ****************** float double and long double Literals *************************
// float d= 34.8;
// long double e=34.8;
// cout<<" the size of operator  :"<<sizeof(34.4);
// cout<<" the size of operator :"<<sizeof(34.4l);
// cout<<" the size of operator :"<<sizeof(34.4L);
// cout<<" the size of operator :"<<sizeof(34.4F);
// cout<<" the size of operator  :"<<sizeof(34.4f);


// ************REFERENCE VARIABLES ***********************
// float x=789;
// float & y= x;
// cout<<x<<endl;
// cout<<y<<endl;

//*************************** type casting *********************
int a=46;
long double  b=89.9876676;
cout<<a<<endl;
cout<<float(a)<<endl;
cout<<b<<endl;
cout<<int(b);

cout<<"the value of expression a+b :"<<a+b<<endl;
cout<<"the value of expression a+int(b) :"<<a+int(b)<<endl;
cout<<"the value of expression a+ :"<<float(a+b)<<endl;



    return 0;
}