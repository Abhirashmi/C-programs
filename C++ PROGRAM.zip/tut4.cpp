#include<iostream>
using namespace std;
int glo=77;
void sum(){
    int a;
    cout<<glo;
}
int main()
{
    int glo=99;
    glo=9;
    int a=9,b=99;
    float pi=3.14;
    char c ='o';
    bool is_true;
sum();
cout<<"hyyyy abhirashmi \n "<<"the value of a is \n "<<a<<"\n the value of b is \n  "<< b;
cout<<is_true;
cout<<"the value of pi is "<<pi;
cout<<"\n the value of c is "<<c;
cout<<"\n the value of glo is "<<glo;
   return 0;
}