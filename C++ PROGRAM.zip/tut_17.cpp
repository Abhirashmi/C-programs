#include<iostream>
using namespace std;
// 

// inline int product(int x, int y){

//     int c= x*y;
//     return c;
// }


int product(int x, int y){
static int c =0;
c=c+1;
    return x*y+c;
}
int main()
{
int a,b;
cout<<"enter the value of a and b";
cin>>a>>b;
product(a,b);

cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;
cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;
cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;
cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;
cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;
cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;
cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;
cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;

cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;
cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;
cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;
cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;

cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;
cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;
cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;
cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;

cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;
cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;
cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;
cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;

cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;
cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;
cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;
cout<<" the product of "<<a<<"and "<<b <<"is "<<product(a,b)<<endl;






 return 0;
 }
