#include<iostream>
using namespace std;
class base1{
public:
void greet(){

    cout<<"hey how are you ??"<<endl;
}
};



class base2{
public:
void greet(){

    cout<<"kaisan baaa ???"<<endl;
}
};


class derive : public base1 , public base2 {
int a;
public:
void greet(){
base2 ::greet();
}


};
int main()
{
    //ambiguity 1
derive d1;
d1.greet();




 return 0;
 }
