
#include <iostream>
using namespace std;

class Complex
{
    int a, b;

public:
    Complex(){
        a = 0;
        b =0;
    }

    Complex(int x, int y)
    {
        a = x;
        b = y;
    }

    Complex(int x){
        a = x;
        b = 0;
    }

  

    void printNumber()
    {
        cout << "Your number is " << a << " + " << b << "i" << endl;
    }
};
int main()
{
    Complex c1(4, 6);
    c1.printNumber();

    Complex c2(5);
    c2.printNumber();

    Complex c3;
    c3.printNumber();
    return 0;
}
// #include<iostream>
// using namespace std;
// class complex{
// int a,b;
// public:
// complex(int x,int y){
//     a=x;
//     b=y;

// }
// complex (int x){
// a=x;
// b=0;


// }

// complex (){
// a=0;
// b=0;


// }

//  void printNumber()
//     {
//         cout << "Your number is " << a << " + " << b << "i" << endl;
//     }


// };

// int main()
// {
//     complex c1(3,8);
// c1.printNumber();

// complex c2(7);
// c2.printNumber();

// complex c3();
// c3.printNumber();


//  return 0;
//  }
