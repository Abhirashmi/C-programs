#include<iostream>
using namespace std;

// float func_Average(int a,int b){
// float avg= (a+b)/2.0;
// return avg;
// }

// float func_Average2(int a,float b){
// float avg= (a+b)/2.0;
// return avg;
// }

template<class T>
void swwap(T &a , T &b){
    T temp =a;
    a=b;
    b=temp;

}

template<class T1,class T2>
float func_Average(T1 a,T2 b){
float avg= (a+b)/2.0;
return avg;
}

int main()
{
    float a;

a = func_Average(3.88,7.99);
printf("the value of function average is %.3f \n ",a);

int x= 5,y=7;
swwap(x,y);
cout<< " values after swaping ";
cout<<x<<"   "<<y<<endl; 

//  float a;

// a = func_Average(3,7);
// printf("the value of function average is %.3f ",a);

// float b;
// b = func_Average2(3,7.9);
// printf("the value of function average is %.3f ",b );


 return 0;
 }
