#include<iostream>
#include<fstream>
using namespace std;

int main()
{
    string st ="oh yes abhi ";
    string st2;
    //opening files using constructor and writing it 
    // ofstream out("sample.txt");
    // out <<st;



    ifstream in("sampleb.txt");
    in>>st2;
    
    getline(in,st2);
    getline(in,st2);
    getline(in,st2);
    cout<<st2;
 return 0;
 }
